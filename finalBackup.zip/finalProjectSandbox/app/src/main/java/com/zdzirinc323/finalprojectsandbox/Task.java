package com.zdzirinc323.finalprojectsandbox;

import java.util.Date;

public class Task {
    private String title, description, duetime;
    private Date duedate;
    private int id,image;




    public Task(int id, String title, String description, Date duedate) {
        this.title = title;
        this.description = description;
        this.duedate = duedate;
        this.image = 0;
    }

    public Task(int id, String title, String description, Date duedate, int image) {
        this.title = title;
        this.description = description;
        this.duedate = duedate;
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public Date getDuedate() {
        return duedate;
    }

    public int getImage() {
        return image;
    }
}
