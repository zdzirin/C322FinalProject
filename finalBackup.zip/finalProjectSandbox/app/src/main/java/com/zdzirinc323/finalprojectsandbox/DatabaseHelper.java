package com.zdzirinc323.finalprojectsandbox;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {


    private static final String DATABASE_NAME = "Notes.db";

    // The first table, used for storing user information
    private static final String TABLE_NAME_1 = "User_Table";
    private static final String USER_COLUMN_1 = "User_id";
    private static final String USER_COLUMN_2 = "User_email";
    private static final String USER_COLUMN_3 = "User_name";

    // The second table, used for storing task information
    private static final String TABLE_NAME_2 = "Task_Table";
    private static final String TASK_COLUMN_1 = "Task_id";
    private static final String TASK_COLUMN_2 = "Task_title";
    private static final String TASK_COLUMN_3 = "Task_description";
    private static final String TASK_COLUMN_4 = "Task_duedate";
    private static final String TASK_COLUMN_5 = "Task_duetime";
    private static final String TASK_COLUMN_6 = "Task_image";
    private static final String TASK_COLUMN_7 = "Task_latitude";
    private static final String TASK_COLUMN_8 = "Task_longitude";
    private static final String TASK_COLUMN_9 = "User_id"; // This is a foreign key from the other table


    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
        //SQLiteDatabase db = this.getWritableDatabase();
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        //SQLite for creating the first table
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_NAME_1 + " ("+USER_COLUMN_1 +" INTEGER PRIMARY KEY AUTOINCREMENT, "+USER_COLUMN_2+" TEXT, "+USER_COLUMN_3+" TEXT)");

        //SQLite for creating the second table
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_NAME_2 + " ("+TASK_COLUMN_1+" INTEGER PRIMARY KEY AUTOINCREMENT, "+TASK_COLUMN_2+" TEXT, "+TASK_COLUMN_3+" TEXT, "+
                TASK_COLUMN_4+" TEXT, "+TASK_COLUMN_5+" TEXT, "+TASK_COLUMN_6+" TEXT, "+TASK_COLUMN_7+" TEXT, "+TASK_COLUMN_8+" TEXT, "+
                TASK_COLUMN_9+" INT, FOREIGN KEY("+TASK_COLUMN_9+") REFERENCES "+TABLE_NAME_1+"("+USER_COLUMN_1+"))");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_1);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_2);
        onCreate(sqLiteDatabase);

    }

    public boolean addUser(String email, String name) {
        //Adds the email and name to table of users.

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cV = new ContentValues();

        cV.put(USER_COLUMN_2, email);
        cV.put(USER_COLUMN_3, name);

        long result =db.insert(TABLE_NAME_1,null,cV);

        //returns true if the data is added succesfully
        return (result == -1) ? false : true;

    }

    public boolean addTask(String title, String description, String duedate, String duetime,
                           String image, String latitude, String longitude, int userID)
    { //Adds a new task to the database

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cV = new ContentValues();

        cV.put(TASK_COLUMN_2, title); cV.put(TASK_COLUMN_3, description);
        cV.put(TASK_COLUMN_4, duedate); cV.put(TASK_COLUMN_5, duetime);
        cV.put(TASK_COLUMN_6, image); cV.put(TASK_COLUMN_7, latitude);
        cV.put(TASK_COLUMN_8, longitude); cV.put(TASK_COLUMN_9, userID);

        long result = db.insert(TABLE_NAME_2, null, cV);
        return (result == -1) ? false : true;

    }

    public Cursor getUserTasks(int user) {
        //Gets all the notes associated with the specified user id

        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM Task_Table WHERE User_id=?", new String[] {Integer.toString(user)});

    }

    public Cursor getUser(int user) {
        //Gets the user associated with the specified user id

        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT User_email, User_name FROM User_Table WHERE User_id=?",
                            new String[] {Integer.toString(user)});

    }

    public int getUserID(String email, String name) {
        //Gets user id matching a name and email

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("SELECT User_id FROM User_Table WHERE User_email=? AND User_name=?", new String[] {email, name});
        c.moveToFirst();
        return c.getInt(0);

    }

}
